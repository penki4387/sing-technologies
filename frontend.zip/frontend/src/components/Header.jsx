import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaCog } from "react-icons/fa";
import WalletModal from "./User/WalletModal";
import axios from "axios";

const Header = () => {
  const navigate = useNavigate();
  const userToken = sessionStorage.getItem("usertoken");
  const userId = sessionStorage.getItem("userId");
  const adminToken = sessionStorage.getItem("admintoken");

  const [wallet, setWallet] = useState([]);
  const [visibleFundingWallet, setVisibleFundingWallet] = useState("0.000000 INR");
  const [selectedCryptoname, setSelectedCryptoname] = useState("INR");
  const [hovered, setHovered] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/user/wallet/${userId}`);
        setWallet(response.data);
      } catch (error) {
        console.error("Error fetching wallet data:", error);
      }
    };
    fetchData();
  }, [userId]);

  useEffect(() => {
    const selectedWallet = wallet.find((entry) => entry.cryptoname === selectedCryptoname);
    if (selectedWallet) {
      setVisibleFundingWallet(`${parseFloat(selectedWallet.balance).toFixed(6)} ${selectedCryptoname}`);
    } else {
      setVisibleFundingWallet("0.000000 INR");
    }
  }, [selectedCryptoname, wallet]);

  const handleLogout = () => {
    sessionStorage.removeItem("usertoken");
    navigate("/login");
  };

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <div
      className="flex flex-row justify-between items-center p-2 lg:p-4 shadow-md w-full fixed h-16 z-50"
      style={{ backgroundColor: "rgba(41, 69, 52, 255)" }}
    >
      {/* App Title */}
      <h1 className="text-white text-sm lg:text-xl font-bold">
        <Link to="/">My App</Link>
      </h1>

      {/* Wallet Information */}
      {userToken && (
        <div className="flex items-center space-x-2 lg:space-x-4">
          <button
            className="bg-gray-800 text-white py-1 px-2 lg:py-2 lg:px-8 rounded text-sm lg:text-md hover:border-transparent"
            onClick={() => setHovered((prev) => !prev)}
          >
            {visibleFundingWallet} ▾
          </button>

          {hovered && (
            <div className="absolute bg-white text-black w-48 mt-4 rounded shadow-lg z-50 max-h-40 overflow-y-auto">
              <ul>
                {wallet.map((entry, index) => (
                  <li
                    key={index}
                    className="flex justify-between items-center p-2 hover:bg-gray-100 cursor-pointer"
                    onClick={() => setSelectedCryptoname(entry.cryptoname)}
                  >
                    <span>{parseFloat(entry.balance).toFixed(6)}</span>
                    <span>{entry.cryptoname}</span>
                  </li>
                ))}
              </ul>
              <button className="flex items-center justify-center py-2 border rounded mt-2">
                <FaCog className="mr-2" /> Wallet Setting
              </button>
            </div>
          )}

          <button
            className="bg-green-500 text-white py-1 px-2 lg:py-2 lg:px-8 rounded text-sm lg:text-md hover:bg-green-700"
            onClick={toggleModal}
          >
            My Wallet
          </button>
        </div>
      )}

      {/* Logout Button */}
      {userToken && (
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white py-1 px-2 lg:py-2 lg:px-8 rounded text-sm lg:text-md font-bold"
          onClick={handleLogout}
        >
          Logout
        </button>
      )}

      {/* Wallet Modal */}
      {isModalOpen && (
        <WalletModal
          visibleFundingWallet={visibleFundingWallet}
          toggleModal={toggleModal}
        />
      )}
    </div>
  );
};

export default Header;
